# 3
# link- https://blog.intigriti.com/

'''
It has all categories in it, that you can see on right side by visiting the provided url
Not using this at now, but method is same just import this to bot.py and then run by providing the CHAT_ID and API_KEY
'''